
# FITFUSION 💪

Sistema completo de avaliação física com:
- Login por e-mail e Google
- Formulário de avaliação
- Histórico por usuário
- Envio automático para WhatsApp

## Como usar:

1. Crie um projeto no [Firebase](https://console.firebase.google.com)
2. Ative:
   - Firestore
   - Autenticação por e-mail/senha e Google
3. Copie suas chaves para o arquivo `firebase-config.js`
4. Publique os arquivos no GitHub Pages ou similar

---

Desenvolvido para: **Projeto FITFUSION**
